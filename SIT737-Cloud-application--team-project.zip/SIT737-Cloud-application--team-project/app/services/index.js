module.exports = {
    signInService:require('./signInService'),
    signUpService:require('./signUpService'),
    TimelineService:require('./timelineService'),
    ProfileService:require('./profileService'),
    searchService:require('./searchService'),
    FriendsService:require('./friendsService'),
    PostService:require('./postService')
}